namespace Practicando_con_Formularios
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnejercicio1_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Form4().Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Form5().Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new Form6().Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new Form7().Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            new Form8().Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            new Form9().Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            new Form10().Show();
            this.Hide();
        }

        private void button16_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            new Form11().Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            new Form12().Show();
            this.Hide();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            new Form13().Show();
            this.Hide();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            new Form14().Show();
            this.Hide();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            new Form15().Show();
            this.Hide();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            new Form16().Show();
            this.Hide();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            new Form17().Show();
            this.Hide();

        }
    }
}
